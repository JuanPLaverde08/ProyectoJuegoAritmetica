package Controlador;

import Modelo.Estudiante;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;


/**
 *
 * @author Juan Pablo Laverde Hernandez
 * @version 1
 * @since 19/05/2020
 */
public class Consultas extends Conexion{
    
    public boolean autenticacion(String usuario, String contraseña){
        
        PreparedStatement pst= null;
        ResultSet rs= null;
        
        try {
            
            String consulta= "select * from persona where usuario= ? and contraseña= ?";
            pst= getConexion().prepareStatement(consulta);
            pst.setString(1, usuario);
            pst.setString(2, contraseña);
            
            rs= pst.executeQuery();
            
            if(rs.absolute(1)){
                return true;
            }
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, "error: " + e);
        
        }finally{
            try {
                
                if(getConexion()!= null) getConexion().close();
                if(pst!= null) pst.close();
                if(rs!= null) rs.close();
            
            } catch (Exception e) {
                
                JOptionPane.showMessageDialog(null, "error: " + e);
            }
        }
        
        return false;
    }
    
    public boolean autenticacionAdmin(String usuarioAdmin, String contraseñaAdmin){
        
        PreparedStatement pst= null;
        ResultSet rs= null;
        
        try {
            
            String consulta= "select * from admin where usuario= ? and contraseña= ?";
            pst= getConexion().prepareStatement(consulta);
            pst.setString(1, usuarioAdmin);
            pst.setString(2, contraseñaAdmin);
            
            rs= pst.executeQuery();
            
            if(rs.absolute(1)){
                return true;
            }
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }finally{
            try {
                
                if(getConexion()!= null) getConexion().close();
                if(pst!= null) pst.close();
                if(rs!= null) rs.close();
            
            } catch (Exception e) {
                
                System.err.println("ERROR"+e);
            }
        }
        
        return false;
    }
    
    public boolean registrar(String usuario, String contraseña, String nombre, String apellido, String correo){
        
        PreparedStatement pst= null;
        
        try {
            
            String consulta= "insert into persona(usuario,contraseña,nombre,apellido,correo,notanivel1,notanivel2,notanivel3,notanivel4,notanivel5) values(?,?,?,?,?,?,?,?,?,?)";
            pst= getConexion().prepareStatement(consulta);
            pst.setString(1, usuario);
            pst.setString(2, contraseña);
            pst.setString(3, nombre);
            pst.setString(4, apellido);
            pst.setString(5, correo);
            pst.setString(6, " ");
            pst.setString(7, " ");
            pst.setString(8, " ");
            pst.setString(9, " ");
            pst.setString(10, " ");
            
            if(pst.executeUpdate()== 1){
                
                return true;
            }
            
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }finally{
            
            try {
                if(getConexion()!= null) getConexion().close();
                if(pst!= null) pst.close();
            } catch (Exception e) {
                
                System.err.println("ERROR"+e);
            }
        }
        
        return false;
    }
    
    public boolean resultadonivel1(String resultado1, String resultado2, String resultado3, String resultado4, String resultado5, String resultado6, String resultado7, String resultado8, String resultado9, String resultado10){
        
        PreparedStatement pst= null;
        ResultSet rs= null;

        try {
            
            String consulta= "select* from nivel1 where resultado1= ? and resultado2= ? and resultado3= ? and resultado4= ? and resultado5= ? and resultado6= ? and resultado7= ? and resultado8= ? and resultado9= ? and resultado10= ?";
            pst= getConexion().prepareStatement(consulta);
            pst.setString(1, resultado1);
            pst.setString(2, resultado2);
            pst.setString(3, resultado3);
            pst.setString(4, resultado4);
            pst.setString(5, resultado5);
            pst.setString(6, resultado6);
            pst.setString(7, resultado7);
            pst.setString(8, resultado8);
            pst.setString(9, resultado9);
            pst.setString(10, resultado10);
            
            rs= pst.executeQuery();
            
            if(rs.absolute(1)){
               
                return true;
            }
            
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }finally{
            try {
                
                if(getConexion()!= null) getConexion().close();
                if(pst!= null) pst.close();
                if(rs!= null) rs.close();
            
            } catch (Exception e) {
                
                System.err.println("ERROR"+e);
            }
        }
        return false;
    }
    
    public boolean resultadonivel2(String resultado1, String resultado2, String resultado3, String resultado4, String resultado5, String resultado6, String resultado7, String resultado8, String resultado9, String resultado10){
        
        PreparedStatement pst= null;
        ResultSet rs= null;
        try {
            
            String consulta= "select* from nivel2 where resultado1= ? and resultado2= ? and resultado3= ? and resultado4= ? and resultado5= ? and resultado6= ? and resultado7= ? and resultado8= ? and resultado9= ? and resultado10= ?";
            pst= getConexion().prepareStatement(consulta);
            pst.setString(1, resultado1);
            pst.setString(2, resultado2);
            pst.setString(3, resultado3);
            pst.setString(4, resultado4);
            pst.setString(5, resultado5);
            pst.setString(6, resultado6);
            pst.setString(7, resultado7);
            pst.setString(8, resultado8);
            pst.setString(9, resultado9);
            pst.setString(10, resultado10);
            
            rs= pst.executeQuery();
            
            if(rs.absolute(1)){
                
                return true;
            }
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }finally{
            try {
                
                if(getConexion()!= null) getConexion().close();
                if(pst!= null) pst.close();
                if(rs!= null) rs.close();
            
            } catch (Exception e) {
                
                System.err.println("ERROR"+e);
            }
        }
        return false;
    }

    public boolean resultadonivel3(String resultado1, String resultado2, String resultado3, String resultado4, String resultado5, String resultado6, String resultado7, String resultado8, String resultado9, String resultado10){
        
        PreparedStatement pst= null;
        ResultSet rs= null;
        try {
            
            String consulta= "select* from nivel3 where resultado1= ? and resultado2= ? and resultado3= ? and resultado4= ? and resultado5= ? and resultado6= ? and resultado7= ? and resultado8= ? and resultado9= ? and resultado10= ?";
            pst= getConexion().prepareStatement(consulta);
            pst.setString(1, resultado1);
            pst.setString(2, resultado2);
            pst.setString(3, resultado3);
            pst.setString(4, resultado4);
            pst.setString(5, resultado5);
            pst.setString(6, resultado6);
            pst.setString(7, resultado7);
            pst.setString(8, resultado8);
            pst.setString(9, resultado9);
            pst.setString(10, resultado10);
            
            rs= pst.executeQuery();
            
            if(rs.absolute(1)){
                
                return true;
            }
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }finally{
            try {
                
                if(getConexion()!= null) getConexion().close();
                if(pst!= null) pst.close();
                if(rs!= null) rs.close();
            
            } catch (Exception e) {
                
                System.err.println("ERROR"+e);
            }
        }
        return false;
    }

    public boolean resultadonivel4(String resultado1, String resultado2, String resultado3, String resultado4, String resultado5, String resultado6, String resultado7, String resultado8, String resultado9, String resultado10){
        
        PreparedStatement pst= null;
        ResultSet rs= null;
        try {
            
            String consulta= "select* from nivel4 where resultado1= ? and resultado2= ? and resultado3= ? and resultado4= ? and resultado5= ? and resultado6= ? and resultado7= ? and resultado8= ? and resultado9= ? and resultado10= ?";
            pst= getConexion().prepareStatement(consulta);
            pst.setString(1, resultado1);
            pst.setString(2, resultado2);
            pst.setString(3, resultado3);
            pst.setString(4, resultado4);
            pst.setString(5, resultado5);
            pst.setString(6, resultado6);
            pst.setString(7, resultado7);
            pst.setString(8, resultado8);
            pst.setString(9, resultado9);
            pst.setString(10, resultado10);
            
            rs= pst.executeQuery();
            
            if(rs.absolute(1)){
                
                return true;
            }
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }finally{
            try {
                
                if(getConexion()!= null) getConexion().close();
                if(pst!= null) pst.close();
                if(rs!= null) rs.close();
            
            } catch (Exception e) {
                
                System.err.println("ERROR"+e);
            }
        }
        return false;
    }

    public boolean resultadonivel5(String resultado1, String resultado2, String resultado3, String resultado4, String resultado5, String resultado6, String resultado7, String resultado8, String resultado9, String resultado10){
        
        PreparedStatement pst= null;
        ResultSet rs= null;
        try {
            
            String consulta= "select* from nivel5 where resultado1= ? and resultado2= ? and resultado3= ? and resultado4= ? and resultado5= ? and resultado6= ? and resultado7= ? and resultado8= ? and resultado9= ? and resultado10= ?";
            pst= getConexion().prepareStatement(consulta);
            pst.setString(1, resultado1);
            pst.setString(2, resultado2);
            pst.setString(3, resultado3);
            pst.setString(4, resultado4);
            pst.setString(5, resultado5);
            pst.setString(6, resultado6);
            pst.setString(7, resultado7);
            pst.setString(8, resultado8);
            pst.setString(9, resultado9);
            pst.setString(10, resultado10);
            
            rs= pst.executeQuery();
            
            if(rs.absolute(1)){
                
                return true;
            }
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }finally{
            try {
                
                if(getConexion()!= null) getConexion().close();
                if(pst!= null) pst.close();
                if(rs!= null) rs.close();
            
            } catch (Exception e) {
                
                System.err.println("ERROR"+e);
            }
        }
        return false;
    }

    public boolean editarNivel1(Estudiante est){
                    
        PreparedStatement pst= null;
        
        try {
            String  estudiante = est.getUsuario();
            System.err.println("estudiante " + estudiante);
            String consulta= "update persona set notanivel1='Completado' where persona.usuario='"+estudiante+"'";
            
            pst= getConexion().prepareStatement(consulta);
            
            if(pst.executeUpdate()== 1){
                
                return true;
            }
            
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }
        return false;
    }
    
    public boolean editarNivel2(Estudiante est){
                    
        PreparedStatement pst= null;
        
        try {
            String  estudiante = est.getUsuario();
            System.err.println("estudiante " + estudiante);
            String consulta= "update persona set notanivel2='Completado' where persona.usuario='"+estudiante+"'";
            
            pst= getConexion().prepareStatement(consulta);
            
            if(pst.executeUpdate()== 1){
                
                return true;
            }
            
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }
        return false;
    }
    
    public boolean editarNivel3(Estudiante est){
                    
        PreparedStatement pst= null;
        
        try {
            String  estudiante = est.getUsuario();
            System.err.println("estudiante " + estudiante);
            String consulta= "update persona set notanivel3='Completado' where persona.usuario='"+estudiante+"'";
            
            pst= getConexion().prepareStatement(consulta);
            
            if(pst.executeUpdate()== 1){
                
                return true;
            }
            
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }
        return false;
    }
    
    public boolean editarNivel4(Estudiante est){
                    
        PreparedStatement pst= null;
        
        try {
            String  estudiante = est.getUsuario();
            System.err.println("estudiante " + estudiante);
            String consulta= "update persona set notanivel4='Completado' where persona.usuario='"+estudiante+"'";
            
            pst= getConexion().prepareStatement(consulta);
            
            if(pst.executeUpdate()== 1){
                
                return true;
            }
            
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }
        return false;
    }
    
    public boolean editarNivel5(Estudiante est){
                    
        PreparedStatement pst= null;
        
        try {
            String  estudiante = est.getUsuario();
            System.err.println("estudiante " + estudiante);
            String consulta= "update persona set notanivel5='Completado' where persona.usuario='"+estudiante+"'";
            
            pst= getConexion().prepareStatement(consulta);
            
            if(pst.executeUpdate()== 1){
                
                return true;
            }
            
        } catch (Exception e) {
            
            System.err.println("ERROR"+e);
        
        }
        return false;
    }

}
