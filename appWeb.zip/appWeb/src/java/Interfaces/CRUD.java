package Interfaces;

import Modelo.Estudiante;
import java.util.List;

/**
 *
 * @author Juan Pablo Laverde Hernandez
 * @version 1
 * @since 22/05/2020
 */
public interface CRUD {
    
    public List listar();
    public Estudiante list(int id);
       
}
