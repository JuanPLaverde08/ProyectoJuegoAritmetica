package Modelo;

/**
 *
 * @author Juan Pablo Laverde Hernandez
 * @version 1
 * @since 22/05/2020
 */
public class Estudiante {
    
    String usuario;
    String nombre;
    String apellido;
    String correo;
    String nivel1;
    String nivel2;
    String nivel3;
    String nivel4;
    String nivel5;

    public Estudiante() {
    }

    public Estudiante(String usuario,String nombre, String apellido, String correo, String nivel1, String nivel2, String nivel3, String nivel4, String nivel5) {
        this.usuario= usuario;
        this.nombre = nombre;
        this.apellido = apellido;
        this.correo = correo;
        this.nivel1 = nivel1;
        this.nivel2 = nivel2;
        this.nivel3 = nivel3;
        this.nivel4 = nivel4;
        this.nivel5 = nivel5;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getNivel1() {
        return nivel1;
    }

    public void setNivel1(String nivel1) {
        this.nivel1 = nivel1;
    }

    public String getNivel2() {
        return nivel2;
    }

    public void setNivel2(String nivel2) {
        this.nivel2 = nivel2;
    }

    public String getNivel3() {
        return nivel3;
    }

    public void setNivel3(String nivel3) {
        this.nivel3 = nivel3;
    }

    public String getNivel4() {
        return nivel4;
    }

    public void setNivel4(String nivel4) {
        this.nivel4 = nivel4;
    }

    public String getNivel5() {
        return nivel5;
    }

    public void setNivel5(String nivel5) {
        this.nivel5 = nivel5;
    }

    
}
