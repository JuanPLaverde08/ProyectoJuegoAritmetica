package ModeloDAO;

import Controlador.Conexion;
import Interfaces.CRUD;
import Modelo.Estudiante;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;


/**
 *
 * @author Juan Pablo Laverde Hernandez
 * @version 1
 * @since 22/05/2020
 */
public class EstudianteDAO implements CRUD{
    
    Conexion cn= new Conexion();
    Connection con;
    PreparedStatement ps;
    ResultSet rs;
    Estudiante e= new Estudiante();
    
    @Override
    public List listar() {
        
        ArrayList<Estudiante>list= new ArrayList<>();
        String sql="select* from persona";
        
        try {
            
            con=cn.getConexion();
            ps=con.prepareStatement(sql);
            rs=ps.executeQuery();
            
            while(rs.next()){
                
                Estudiante est= new Estudiante();
                est.setUsuario(rs.getString("usuario"));
                est.setNombre(rs.getString("nombre"));
                est.setApellido(rs.getString("apellido"));
                est.setCorreo(rs.getString("correo"));
                est.setNivel1(rs.getString("notanivel1"));
                est.setNivel2(rs.getString("notanivel2"));
                est.setNivel3(rs.getString("notanivel3"));
                est.setNivel4(rs.getString("notanivel4"));
                est.setNivel5(rs.getString("notanivel5"));
                list.add(est);
            }
            
        } catch (Exception e) {
        
        }
        
        return list;
    }

    @Override
    public Estudiante list(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
